package dev.marshall.visualsearch.model

data class Model_product(val title:String="",
                         val price:Double= 0.0,
                         val description:String="",
                         val imUrl:String="")