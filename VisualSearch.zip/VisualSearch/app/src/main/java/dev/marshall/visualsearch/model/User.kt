package dev.marshall.visualsearch.model

data class User(val username :String="",
                val phonenumber :String="",
                val shipping_address :String="",
                val image:String="")